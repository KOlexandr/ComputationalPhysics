function z = f3 (v) % y'=v;
z = v;